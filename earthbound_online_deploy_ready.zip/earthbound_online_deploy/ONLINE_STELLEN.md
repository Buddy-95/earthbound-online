# Earthbound Online online stellen (Render)

## Wichtig
Ich kann keine Hosting-Konten anlegen, keine AGB akzeptieren und keine Veröffentlichung in deinem Namen auslösen, solange du keinen Hosting-Zugang ausdrücklich verbunden und freigegeben hast. Dieses Paket ist für die Veröffentlichung vorbereitet.

## Einfachster Weg über Render
1. Erstelle ein GitHub-Repository und lade alle Dateien dieses Ordners hoch (auch `render.yaml`).
2. Melde dich bei Render an und verbinde GitHub.
3. Wähle **New + → Blueprint** und das Repository mit `render.yaml`.
4. Prüfe den Plan und bestätige die Erstellung. Die Konfiguration nutzt Region Frankfurt und ein persistentes 1-GB-Datenträger-Volume für SQLite.
5. Warte auf den erfolgreichen Build. Öffne die von Render angezeigte `https://...onrender.com`-Adresse.
6. Prüfe `/api/health` — erwartet wird `{"ok":true,"service":"earthbound-online"}`.

## Dateien
- `render.yaml`: Render-Service, Frankfurt-Region und persistenter Speicher
- `Dockerfile`: alternative Container-Konfiguration
- `server.js`: Backend und `/api/health`

## Vor öffentlicher Veröffentlichung beachten
Das ist ein früher Prototyp. Für öffentliche Accounts fehlen unter anderem E-Mail-Verifizierung und Passwort-Reset; Sessions liegen im localStorage; die API benötigt vor einem größeren öffentlichen Launch weitere Sicherheitsprüfung, Monitoring und Backups. SQLite ist für einen einzelnen Server okay, nicht für horizontale Skalierung. Veröffentliche es zunächst als Testversion und verwende kein Passwort, das du anderswo nutzt.
