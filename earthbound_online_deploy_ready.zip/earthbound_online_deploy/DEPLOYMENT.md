# Deployment und Sicherheit

## Lokaler Start
Voraussetzung: Node.js 20+ und npm.

```bash
npm install
npm start
```

Öffne danach http://localhost:3000. SQLite-Datenbank wird automatisch unter `data/earthbound.sqlite` angelegt.

## Persistenz
- Accounts: Benutzername + bcrypt-gehashter Passwort-Hash
- Session: kryptografisch zufälliges Bearer-Token, serverseitig nur als SHA-256-Hash gespeichert, Ablauf nach 30 Tagen
- Charakter: Name, Klasse, Aussehen, Level, XP, Münzen und Weltkoordinaten
- Inventar: Mengen je Item, mit Fremdschlüssel zum Charakter
- Weltfortschritt: gesammelte Runensplitter
- Transaktionen für Charakter-Starterinventar und Sammelbelohnungen

## Grenzen
- Ein Charakter pro Account; E-Mail-Verifizierung und Passwort-Reset fehlen.
- Der Token wird clientseitig in localStorage gehalten. Für eine öffentliche Produktion sollte man auf sichere HttpOnly-Cookies, CSRF-Schutz, TLS, striktere Rate Limits, Monitoring und ein abgestimmtes Session-Management wechseln.
- Das Projekt ist kein autoritativer Echtzeit-Multiplayer-Server. Die Sammel-API ist serverseitig begrenzt, aber Bewegung/Kollision/Kampf werden noch nicht simuliert.
- Die Weltkarte deckt global ab. Die vollständige Erde ist nicht als detailreiche 3D-Geometrie geladen; die Karte verwendet OSM-Kacheln. Beachte die OSM-Attribution, ODbL und die Nutzungsrichtlinien der Dienste.
- Für öffentliche Bereitstellung `DATA_DIR` auf ein persistentes Volume setzen. Nicht mehrere Serverinstanzen mit derselben SQLite-Datei betreiben; bei Skalierung auf PostgreSQL wechseln.
