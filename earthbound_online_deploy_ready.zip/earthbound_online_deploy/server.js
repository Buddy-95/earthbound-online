const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'earthbound.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS characters (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 archetype TEXT NOT NULL,
 appearance TEXT NOT NULL DEFAULT 'wanderer',
 level INTEGER NOT NULL DEFAULT 1,
 xp INTEGER NOT NULL DEFAULT 0,
 coins INTEGER NOT NULL DEFAULT 25,
 lat REAL NOT NULL DEFAULT 47.585,
 lon REAL NOT NULL DEFAULT 14.2,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inventory (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 character_id INTEGER NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
 item_key TEXT NOT NULL,
 item_name TEXT NOT NULL,
 quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity >= 0),
 UNIQUE(character_id, item_key)
);
CREATE TABLE IF NOT EXISTS world_progress (
 character_id INTEGER PRIMARY KEY REFERENCES characters(id) ON DELETE CASCADE,
 shards INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const q = {
 userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
 userById: db.prepare('SELECT id, username, created_at FROM users WHERE id = ?'),
 createUser: db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)'),
 createSession: db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)'),
 sessionUser: db.prepare(`SELECT u.id,u.username,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?`),
 deleteSession: db.prepare('DELETE FROM sessions WHERE token_hash=?'),
 character: db.prepare('SELECT * FROM characters WHERE user_id=?'),
 createCharacter: db.prepare('INSERT INTO characters(user_id,name,archetype,appearance) VALUES(?,?,?,?)'),
 inventory: db.prepare('SELECT item_key AS key,item_name AS name,quantity FROM inventory WHERE character_id=? AND quantity>0 ORDER BY item_name'),
 item: db.prepare('SELECT * FROM inventory WHERE character_id=? AND item_key=?'),
 addItem: db.prepare(`INSERT INTO inventory(character_id,item_key,item_name,quantity) VALUES(?,?,?,?)
   ON CONFLICT(character_id,item_key) DO UPDATE SET quantity=quantity+excluded.quantity`),
 progress: db.prepare('SELECT shards FROM world_progress WHERE character_id=?'),
 initProgress: db.prepare('INSERT OR IGNORE INTO world_progress(character_id) VALUES(?)'),
 saveLocation: db.prepare('UPDATE characters SET lat=?,lon=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?'),
 updateProgress: db.prepare('UPDATE world_progress SET shards=?,updated_at=CURRENT_TIMESTAMP WHERE character_id=?'),
 updateXP: db.prepare('UPDATE characters SET xp=?,level=?,coins=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')
};
const starterItems = [
 ['field_tonic','Feldtrank',3],
 ['wooden_staff','Reisestab',1],
 ['hearth_rune','Heimkehr-Rune',1]
];
const validArchetypes = new Set(['Wächter','Arkanist','Waldläufer']);
const validAppearances = new Set(['wanderer','ranger','mage']);
const authLimiter = rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false,message:{error:'Zu viele Anfragen. Bitte warte kurz.'}});
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false, crossOriginEmbedderPolicy:false}));
app.use(express.json({limit:'20kb'}));
app.use('/api/register', authLimiter);
app.use('/api/login', authLimiter);
app.get('/api/health',(req,res)=>res.json({ok:true,service:'earthbound-online'}));
app.use(express.static(path.join(__dirname,'public')));
function fail(res,status,error){ return res.status(status).json({error}); }
function tokenHash(token){ return crypto.createHash('sha256').update(token).digest('hex'); }
function getToken(req){ const h=req.get('authorization')||''; return h.startsWith('Bearer ')?h.slice(7):''; }
function auth(req,res,next){
 const token=getToken(req); if(!token) return fail(res,401,'Bitte anmelden.');
 const row=q.sessionUser.get(tokenHash(token));
 if(!row || row.expires_at < Date.now()){
   if(row) q.deleteSession.run(tokenHash(token));
   return fail(res,401,'Sitzung abgelaufen. Bitte erneut anmelden.');
 }
 req.user={id:row.id,username:row.username}; req.tokenHash=tokenHash(token); next();
}
function publicCharacter(userId){
 const c=q.character.get(userId); if(!c) return null;
 q.initProgress.run(c.id);
 const p=q.progress.get(c.id);
 return {...c,shards:p?.shards||0,inventory:q.inventory.all(c.id)};
}
function issueSession(userId){
 const token=crypto.randomBytes(32).toString('base64url');
 q.createSession.run(tokenHash(token),userId,Date.now()+1000*60*60*24*30);
 return token;
}
app.post('/api/register',(req,res)=>{
 const username=String(req.body.username||'').trim();
 const password=String(req.body.password||'');
 if(!/^[A-Za-z0-9_ÄÖÜäöü-]{3,20}$/.test(username)) return fail(res,400,'Benutzername: 3–20 Zeichen, Buchstaben, Zahlen, _ oder -.');
 if(password.length<10 || password.length>128) return fail(res,400,'Passwort muss 10–128 Zeichen lang sein.');
 if(q.userByName.get(username)) return fail(res,409,'Dieser Benutzername ist bereits vergeben.');
 try{
   const info=q.createUser.run(username,bcrypt.hashSync(password,12));
   const userId=Number(info.lastInsertRowid), token=issueSession(userId);
   res.status(201).json({token,user:q.userById.get(userId),character:null});
 }catch(e){console.error(e);fail(res,500,'Registrierung fehlgeschlagen.');}
});
app.post('/api/login',(req,res)=>{
 const username=String(req.body.username||'').trim(), password=String(req.body.password||'');
 const u=q.userByName.get(username);
 if(!u || !bcrypt.compareSync(password,u.password_hash)) return fail(res,401,'Benutzername oder Passwort stimmt nicht.');
 const token=issueSession(u.id);
 res.json({token,user:q.userById.get(u.id),character:publicCharacter(u.id)});
});
app.post('/api/logout',auth,(req,res)=>{q.deleteSession.run(req.tokenHash);res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({user:q.userById.get(req.user.id),character:publicCharacter(req.user.id)}));
app.post('/api/character',auth,(req,res)=>{
 if(q.character.get(req.user.id)) return fail(res,409,'Du hast bereits einen Charakter.');
 const name=String(req.body.name||'').trim(), archetype=String(req.body.archetype||''), appearance=String(req.body.appearance||'wanderer');
 if(!/^[\p{L}\p{N} _'-]{3,20}$/u.test(name)) return fail(res,400,'Charaktername muss 3–20 Zeichen haben.');
 if(!validArchetypes.has(archetype)) return fail(res,400,'Ungültige Klasse.');
 if(!validAppearances.has(appearance)) return fail(res,400,'Ungültiges Aussehen.');
 try{
  const create=db.transaction(()=>{
    const r=q.createCharacter.run(req.user.id,name,archetype,appearance);
    const id=Number(r.lastInsertRowid);
    for(const [key,item,qty] of starterItems) db.prepare('INSERT INTO inventory(character_id,item_key,item_name,quantity) VALUES(?,?,?,?)').run(id,key,item,qty);
    q.initProgress.run(id);
  }); create();
  res.status(201).json({character:publicCharacter(req.user.id)});
 }catch(e){console.error(e);fail(res,500,'Charakter konnte nicht erstellt werden.');}
});
app.get('/api/inventory',auth,(req,res)=>{
 const c=q.character.get(req.user.id); if(!c)return fail(res,404,'Erstelle zuerst einen Charakter.');
 res.json({items:q.inventory.all(c.id)});
});
app.post('/api/location',auth,(req,res)=>{
 const lat=Number(req.body.lat),lon=Number(req.body.lon);
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat < -90||lat>90||lon < -180||lon>180) return fail(res,400,'Ungültige Koordinaten.');
 if(!q.character.get(req.user.id))return fail(res,404,'Erstelle zuerst einen Charakter.');
 q.saveLocation.run(lat,lon,req.user.id);res.json({ok:true,lat,lon});
});
app.post('/api/collect',auth,(req,res)=>{
 const c=q.character.get(req.user.id); if(!c)return fail(res,404,'Erstelle zuerst einen Charakter.');
 // Server validates item reward type; client cannot choose item or reward amount.
 const p=q.progress.get(c.id); q.initProgress.run(c.id);
 const current=q.progress.get(c.id).shards;
 if(current>=1000)return fail(res,400,'Sammelgrenze erreicht.');
 const shards=current+1, totalXp=c.xp+35;
 let level=c.level,xp=totalXp,coins=c.coins;
 while(xp>=level*100){xp-=level*100;level++;coins+=10;}
 const tx=db.transaction(()=>{
  q.updateProgress.run(shards,c.id);q.updateXP.run(xp,level,coins,c.id);
  q.addItem.run(c.id,'rune_shard','Runensplitter',1);
 });
 tx();
 res.json({character:publicCharacter(req.user.id),reward:{xp:35,level,coins}});
});
app.use('/api/*',(req,res)=>fail(res,404,'API-Endpunkt nicht gefunden.'));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Earthbound Online läuft auf http://localhost:${PORT}`));
